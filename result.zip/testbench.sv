// Code your testbench here
// or browse Examples
module tb_d_ff();
  reg d;
  reg clk;
  reg rst;
  wire q;
  d_ff dut(.d(d),.clk(clk),.rst(rst),.q(q));
  
  initial clk = 0;
always #5 clk = ~clk;   // 10ns clock period
  
  initial begin
  rst = 1; 
  #15 rst = 0;   // release reset after 15 time units
end

  initial begin 
  $dumpfile("dump.vcd"); $dumpvars;
  end
  
 
  initial begin
  d = 0;
  #20 d = 1;
  #20 d = 0;
  #20 d = 1;
  #20 d = 0;
  #20 d = 1;
  #20 $finish;
end

endmodule
    